<?php
// Database configuration
$host = 'localhost';
$dbname = 'test';
$username = 'root';
$password = '';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Headers
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit;
}

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve product data
    $productName = $_POST['productName'] ?? null;
    $productSKU = $_POST['productSKU'] ?? null;
    $productID = $_POST['productID'] ?? null;
    $productCategory = $_POST['productCategory'] ?? null;
    $productDescription = $_POST['productDescription'] ?? null;
    $productBenefits = $_POST['productBenefits'] ?? null;
    $productUsage = $_POST['productUsage'] ?? null;
    $selectedTags = $_POST['selectedTags'] ?? null;



    // Process key benefits into JSON format
    $keyBenefitsArray = $_POST['keyBenefits'] ?? [];
    $keyBenefitsJson = json_encode($keyBenefitsArray);

    // Image upload configuration
    $uploadDir = 'uploads/'; // Ensure this directory exists and is writable
    $uploadedFileNames = [];

    if (!empty($_FILES['productMedia']['name'][0])) {
        foreach ($_FILES['productMedia']['name'] as $index => $originalFileName) {
            if (!empty($originalFileName)) {
                $fileExtension = strtolower(pathinfo($originalFileName, PATHINFO_EXTENSION));
                $fileName = pathinfo($originalFileName, PATHINFO_FILENAME);

                // Check for allowed file types
                $allowedImageExtensions = ['jpg', 'jpeg', 'png', 'gif'];
                $allowedVideoExtensions = ['mp4', 'avi', 'mov', 'mkv'];
                $isImage = in_array($fileExtension, $allowedImageExtensions);
                $isVideo = in_array($fileExtension, $allowedVideoExtensions);

                if (!$isImage && !$isVideo) {
                    echo json_encode(['success' => false, 'message' => "Unsupported file type: $originalFileName"]);
                    exit;
                }

                // Generate a unique file name
                $newFileName = $fileName . '.' . $fileExtension;
                $counter = 1;
                while (file_exists($uploadDir . $newFileName)) {
                    $newFileName = $fileName . '_' . $counter . '.' . $fileExtension;
                    $counter++;
                }

                // Move the uploaded file
                if (move_uploaded_file($_FILES['productMedia']['tmp_name'][$index], $uploadDir . $newFileName)) {
                    $uploadedFileNames[] = $newFileName;
                } else {
                    echo json_encode(['success' => false, 'message' => "Failed to upload file: $originalFileName"]);
                    exit;
                }
            }
        }

        // Success response
        echo json_encode(['success' => true, 'uploadedFiles' => $uploadedFileNames]);
    } else {
        echo json_encode(['success' => false, 'message' => 'No files uploaded.']);
    }

    // Process variant data into JSON format
    $productQuantities = $_POST['productQuantity'] ?? [];
    $productPrices = $_POST['quantityPrice'] ?? [];
    $productStocks = $_POST['productStock'] ?? [];
    $sellingPrices = $_POST['sellingPrice'] ?? [];
    $productTax = $_POST['productTax'] ?? [];
    $discounts = $_POST['discount'] ?? [];
    $variantsArray = [];

    foreach ($productQuantities as $index => $quantity) {
        $price = $productPrices[$index] ?? 0;
        $stock = $productStocks[$index] ?? 0;
        $sellingPrice = $sellingPrices[$index] ?? 0;
        $productTax = $productTax[$index] ?? 0;
        $discount = $discounts[$index] ?? 0;

        // Define each variant with a unique key like 'variant1', 'variant2', etc.
        $variantsArray['variant' . ($index + 1)] = [
            'quantity' => $quantity,
            'price' => $price,
            'discount' => $discount,
            'sellingPrice' => $sellingPrice,
            'stock' => $stock,
            'productTax' => $productTax,
        ];
    }

    $variantsJson = json_encode($variantsArray);

    // Optionally, store or print the JSON string
    // echo $variantsJson;

    // Insert all data into the `products` table in JSON format
    $stmt = $conn->prepare("INSERT INTO products_new (product_name, sku, product_id, category, description, benefits, product_usage, key_benefits, selected_tags, variants, image_paths) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
        exit;
    }

    $imagePathsJson = json_encode($uploadedFileNames);
    $stmt->bind_param("sssssssssss", $productName, $productSKU, $productID, $productCategory, $productDescription, $productBenefits, $productUsage, $keyBenefitsJson, $selectedTags, $variantsJson, $imagePathsJson);

    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Execute failed: ' . $stmt->error]);
        exit;
    }

    // Success response
    echo json_encode(['success' => true, 'message' => 'Product and variants added successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}


$response = [
    'success' => empty($errors),
    'uploadedFiles' => $uploadedFileNames,
    'errors' => $errors,
    'message' => empty($errors) ? 'Product and variants added successfully' : 'Some files could not be uploaded.',
];

ob_end_clean();
echo json_encode($response);
exit;
// Close the connection
$conn->close();
