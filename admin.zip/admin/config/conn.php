<?php

// Database configuration
$host = 'localhost';
$dbname = 'test';
$username = 'root';
$password = '';


// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit;
}
